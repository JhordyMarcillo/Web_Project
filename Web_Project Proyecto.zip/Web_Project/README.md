## Web Project (es)

Este projecto está realizado para la asignatura de programación web, 
en donde se gestiona un inventario. Este posee roles como administrador, 
bodeguero y personal para ventas, así mismo un control de productos, de ventas y de stock. 
Util para empresas pequeñas, personas que requieran un software para la gestión de inventario

## Web Project (en)

This project It is designed for the web programming subject, 
where an inventory is managed. It has roles such as administrator, 
warehouseman and sales staff, as well as control of products, sales and stock. 
Useful for small businesses, people who require software for inventory management.
